v0.0.2
------

* Repack cookbook

