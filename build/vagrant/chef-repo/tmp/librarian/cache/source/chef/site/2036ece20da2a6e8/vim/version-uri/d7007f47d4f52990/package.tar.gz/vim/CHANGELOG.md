vim Cookbook CHANGELOG
======================
This file is used to list changes made in each version of the vim cookbook.

v1.1.2 (2013-12-30)
-------------------
Fixing Ubuntu package installer bug. Adding specs.


v1.1.0
------
### Improvement
- **[COOK-2465](https://tickets.opscode.com/browse/COOK-2465)** - Add a compile and settings optional recipe.


v0.0.0
------
Text goes here
