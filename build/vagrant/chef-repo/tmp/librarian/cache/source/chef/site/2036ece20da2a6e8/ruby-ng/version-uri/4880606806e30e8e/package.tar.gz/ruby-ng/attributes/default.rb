default['ruby-ng']['experimental'] = false
default['ruby-ng']['ruby_version'] = '2.1'
